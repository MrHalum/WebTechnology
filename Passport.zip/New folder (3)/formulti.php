<!DOCTYPE html>
<html>
    <head><b><h1>PASSPORT APPLICATION - Final</h1></b></head>
	<head><b><h4 style="Color:red">Reminder before submitting your application </h4></b></head>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
	<fieldset>
		<legend></legend>
    <body>
        
        <form method='GET' action='index.php'>
        <?php include('file.php')?>
        <br>
			

        <button type='submit' name='Exit'>Exit</button>

        </form>
    </body>
</html>